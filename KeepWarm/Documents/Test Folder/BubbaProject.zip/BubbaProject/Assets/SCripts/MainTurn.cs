﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class MainTurn : MonoBehaviour {

    public float timeLeft;
    public int playerGuy = 1;
    GameObject PlayerOne;
    GameObject PlayerTwo;
    ClickPlay StartScript;

    // Use this for initialization
    void Start () {
        
         PlayerTwo = GameObject.FindGameObjectWithTag("Player2");
         PlayerOne = GameObject.FindGameObjectWithTag("Player");
        
        
        PlayerTwo.GetComponent<Player_Two_Move_Prot>().enabled = false;
        PlayerOne.GetComponent<Player_Move_Prot>().enabled = false;

        timeLeft = Time.time;
        
    }
	
	// Update is called once per frame
	void Update () {
        
        if ((Time.time-timeLeft) > 5)
        {
            SwitchTurn();
            timeLeft = Time.time;
            
        }

    }

    void SwitchTurn()
    {
        if (playerGuy==1)
        {
            PlayerOne.GetComponent<Player_Move_Prot>().enabled = false;
            PlayerTwo.GetComponent<Player_Two_Move_Prot>().enabled = true;
            playerGuy = 2;

        }
        else
        {
            PlayerOne.GetComponent<Player_Move_Prot>().enabled = true;
            PlayerTwo.GetComponent<Player_Two_Move_Prot>().enabled = false;
            playerGuy = 1;

        }

    }
}
