﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class ClickPlay : MonoBehaviour
{

    public Button playButton;
    public GameObject[] a1;
    public GameObject[] a2;
    public GameObject[] a3;
    public GameObject[] a4;
    public GameObject[] a5;
    

        // Use this for initialization
    public void Start()
    {

        //  a1 = GameObject.FindGameObjectsWithTag("Art");
        //  foreach (GameObject i in a1)
        //  {
        //      i.SetActive(true);
        //  }

        //a2 = GameObject.FindGameObjectsWithTag("Food");
        // foreach (GameObject j in a2)
        // {
        //     j.SetActive(false);
        // }

        // a3 = GameObject.FindGameObjectsWithTag("Player");
        // foreach (GameObject j2 in a2)
        //  {
        //       j2.SetActive(false);
        //  }

        //  a4 = GameObject.FindGameObjectsWithTag("Player2");
        //   foreach (GameObject j3 in a4)
        //   {
        //       j3.SetActive(false);
        //   }

        // a5 = GameObject.FindGameObjectsWithTag("Curtain");
        //  foreach (GameObject j4 in a5)
        // {
        //      j4.SetActive(true);
        //  }
        
        

    }

    public void game2p()
    {
        a1 = GameObject.FindGameObjectsWithTag("Art");
        foreach (GameObject i in a1)
        {
            i.SetActive(true);
        }

        a2 = GameObject.FindGameObjectsWithTag("Food");
        foreach (GameObject j in a2)
        {
            j.SetActive(true);
        }

        a3 = GameObject.FindGameObjectsWithTag("Player");
        foreach (GameObject j2 in a2)
        {
            j2.SetActive(true);
        }

        a4 = GameObject.FindGameObjectsWithTag("Player2");
        foreach (GameObject j3 in a4)
        {
            j3.SetActive(true);
        }

        a5 = GameObject.FindGameObjectsWithTag("Curtain");
        foreach (GameObject j4 in a5)
        {
            j4.SetActive(false);
        }
    }

    public void quitButton()
    {
        Application.Quit();
    }

    public void TaskOnClick()
    {
        //menu.SetActive(false);
    }
    // Update is called once per frame
    public void Update()
    {

    }
}

