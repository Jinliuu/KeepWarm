﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerPositions : MonoBehaviour
{



    // Update is called once per frame

    private float xTake = 0;
    private float xTakeN = 0;
    private float yTake = 0;
    private float yTakeN = 0;
    private float x1Take = 0;
    private float x1TakeN = 0;
    private float y1Take = 0;
    private float y1TakeN = 0;
    private float foodTake = 0;
    private float foodTake2 = 0;
    private float p2Enabled = 0;
    private float p2Turned = 0;
    private float p1Turned = 0;
    private void Start()
    {
        Player_Two_Move_Prot test1 = new Player_Two_Move_Prot();
        test1.moveX2 = 0;

        test1.moveY2 = 0;

        Player_Move_Prot test11 = new Player_Move_Prot();
        test11.moveX12 = 0;

        test11.moveY12 = 0;
    }

    void Update()
    {

        var h = Input.GetAxisRaw("Horizontal");

        var x = h * 0.5f * Time.deltaTime;

        var movement = new Vector2(x, 0);

        Player_Two_Move_Prot test1 = new Player_Two_Move_Prot();

        Player_Move_Prot test11 = new Player_Move_Prot();

        test11.moveX12 += x;

        x1Take = test11.moveX12;


        test1.moveX2 += x;

        xTake = test1.moveX2;



        foodTake = test1.eating;
        foodTake2 = test11.eating1;

        if (test1.moveX2 != 0.5)
        {
            p2Enabled = 1;
        }
        else
        {
            p2Enabled = 0;
        }

        if (test1.facingRight)
        {

            p2Turned = 1;
        }
        else
        {
            p2Turned = 0;
        }

        if (test11.fr2)
        {

            p1Turned = 1;
        }
        else
        {
            p1Turned = 0;
        }

    }

    public float CalculateMovement(float h, int r)
    {
        if (r == 1)
        {

            xTakeN =xTake- (xTake * h);
           if (xTakeN < xTake)
            {
                return 1;
            }
            else
            {
                return 0;
            }
            
        }
        else if (r == 2)
        {
            xTakeN = xTake+ (xTake * h);
           
            if (xTakeN > xTake)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        else if (r == 3)
        {
            yTakeN = yTake + (yTake * h);

            if (yTakeN > yTake)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }

        else if (r == 4)
        {
            yTakeN = yTake - (yTake * h);

            if (yTakeN < yTake)
            {
                return 1;
            }
            else
            {
                return 0;
            }

        }

        if (r == 5)
        {
            x1TakeN = x1Take - (x1Take * h);
            if (x1TakeN < x1Take)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        else if (r == 6)
        {
            x1TakeN = x1Take + (x1Take * h);
            if (x1TakeN > x1Take)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        else if (r == 7)
        {
            yTakeN = y1Take + (y1Take * h);
            if (yTakeN > y1Take)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }

        else
        {
            yTakeN = y1Take - (y1Take * h);
            if (yTakeN < y1Take)
            {
                return 1;
            }
            else
            {
                return 0;
            }

        }

        
    }

    public float CalculateCollection(float h, int r)
    {
        if (r == 1)
        {
            return foodTake * h;
        }
        else
            return foodTake2;
    }

    public float CalculateVictory(int r)
    {
        if (r == 1)
        {
            return foodTake2;
        }
        else
            return foodTake;
    }

    public float CalculatePress(int r)
    {
        if (r == 1 || r == 2)
        {
            return p2Enabled;

        }
        else
            return p2Enabled;
    }

    public float CalculateSwitch(int r)
    {
        if (r == 1 || r == 3)
        {
            return p1Turned;

        }
        else
            return p2Turned;
    }

    public float CalculateScen(int r)
    {
        return 0;

    }
}
