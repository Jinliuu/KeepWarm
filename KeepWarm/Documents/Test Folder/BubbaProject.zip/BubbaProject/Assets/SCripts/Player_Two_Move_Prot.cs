﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class Player_Two_Move_Prot : MonoBehaviour {


    public float playerSpeed2 = 0.5f;
    public bool facingRight = true;
    public int playeJumpPower = 1250;
    private float moveX;
    public float moveX2;
    public float eating = 0;
    private float moveY;
    public float moveY2;
    private bool canClimb = false; 
    // Use this for initialization
    private int foodCounter = 0;
    public GameObject[] wall1;
    ClickPlay StartScript;

    private void Start()
    {
        //GameObject varGameObject2 = GameObject.FindGameObjectWithTag("Player");
        // varGameObject2.GetComponent<Player_Move_Prot>().enabled = false;
        
    }

    // Update is called once per frame
    void Update()
    {

        PlayerMove();
        if (canClimb)
        {
            if (Input.GetKey(KeyCode.UpArrow))
            {
                gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(0, playerSpeed2);

                wall1 = GameObject.FindGameObjectsWithTag("ladWall");
                foreach (GameObject i in wall1)
                {
                    i.SetActive(true);
                }
            }
            else
            {
                wall1 = GameObject.FindGameObjectsWithTag("ladWall");
                foreach (GameObject i in wall1)
                {
                    i.SetActive(false);
                }
            }


        }

    }

    void PlayerMove()
    {
        //Controls
        moveX = Input.GetAxis("Horizontal");
        moveX2 = moveX;
        //Animation
        //Player Direction
        if (moveX < 0.0f && facingRight == false)
        {
            FlipPlayer();
        }
        else if (moveX > 0.0f && facingRight == true)
        {
            FlipPlayer();
        }
        //Physics
        gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(moveX * playerSpeed2, gameObject.GetComponent<Rigidbody2D>().velocity.y);

    }

    void Jump()
    {
        //Jumping Code
    }

    void FlipPlayer()
    {
        facingRight = !facingRight;
        Vector2 localScale = gameObject.transform.localScale;
        localScale.x *= -1;
        transform.localScale = localScale;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Food"))
        {
            foodCounter = foodCounter + 1;
            other.gameObject.SetActive(false);
            eating = eating + 1;

        }

        if (other.gameObject.CompareTag("Ladder"))
        {
            canClimb = true;

        }

        if (other.gameObject.CompareTag("sun"))
        {
            canClimb = false;

        }




        if (foodCounter == 2)
        {
            SceneManager.LoadScene(0);
        }


    }

}
