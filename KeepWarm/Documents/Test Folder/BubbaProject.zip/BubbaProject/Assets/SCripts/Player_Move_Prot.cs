﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;


public class Player_Move_Prot : MonoBehaviour {

    private float playerSpeed = 0.5f;
    private bool facingRight = false;
    public bool fr2=false;
    public float eating1 = 0;
    private float moveX;
    private float moveY;
    public float moveX12;
    public float moveY12;
    private int foodCounter = 0;
    private bool canClimb = false;
    // Use this for initialization
    //GameObject varGameObject2;
    ClickPlay StartScript;


    private void Start()
    {
        //GameObject varGameObject2 = GameObject.FindGameObjectWithTag("Player");
        // varGameObject2.GetComponent<Player_Move_Prot>().enabled = false;
       

    }


    // Update is called once per frame
    private void Update() {
        PlayerMove();

        if (canClimb)
        {
            if (Input.GetKey(KeyCode.UpArrow))
            {
                gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(0, playerSpeed);
            }
            

        }


    }

    private void PlayerMove()
    {
        //Controls
        moveX = Input.GetAxis("Horizontal");
        moveX12=moveX;
        //Animation
        //Player Direction
        if (moveX < 0.0f && facingRight == false) {
            FlipPlayer();
        }
        else if (moveX > 0.0f && facingRight == true)
        {
            FlipPlayer();
        }
        //Physics
        gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(moveX * playerSpeed, gameObject.GetComponent<Rigidbody2D>().velocity.y);

    }

    

    

    private void FlipPlayer()
    {
        facingRight = !facingRight;
        fr2 = facingRight;
    Vector2 localScale = gameObject.transform.localScale;
        localScale.x *= -1;
        transform.localScale = localScale;
        
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Food"))
        {
            foodCounter = foodCounter + 1;
            other.gameObject.SetActive(false);
            eating1 = eating1 + 1;

        }

        if (other.gameObject.CompareTag("Ladder"))
        {
            canClimb = true;

        }

        if (other.gameObject.CompareTag("sun"))
        {
            canClimb = false;

        }




        if (foodCounter == 2)
        {
            SceneManager.LoadScene(0);
        }



    }

}
