﻿using UnityEngine;
using UnityEngine.TestTools;
using NUnit.Framework;
using System.Collections;

public class PlayButtonTest {

	//player 2 Movement 
    [UnityTest]
    public void moveLeft_Input()
    {
        Assert.AreEqual(1, new PlayerPositions().CalculateMovement(1,1));
    }
    [UnityTest]
    public void moveRight_Input()
    {
        Assert.AreEqual(1, new PlayerPositions().CalculateMovement(1,2), 0.1f);
    }
    [UnityTest]
    public void moveUp_Input()
    {
        Assert.AreEqual(1, new PlayerPositions().CalculateMovement(1,3), 0.1f);
    }
    [UnityTest]
    public void moveDown_Input()
    {
        Assert.AreEqual(1, new PlayerPositions().CalculateMovement(1,4), 0.1f);
    }

    //end of p2 movement

    // Player 1 Movement
    [UnityTest]
    public void moveLeft2_Input()
    {
        Assert.AreEqual(1, new PlayerPositions().CalculateMovement(1, 5), 0.1f);
    }
    [UnityTest]
    public void moveRight2_Input()
    {
        Assert.AreEqual(1, new PlayerPositions().CalculateMovement(1, 6), 0.1f);
    }
    [UnityTest]
    public void moveUp2_Input()
    {
        Assert.AreEqual(1, new PlayerPositions().CalculateMovement(1, 7), 0.1f);
    }
    [UnityTest]
    public void moveDown2_Input()
    {
        Assert.AreEqual(1, new PlayerPositions().CalculateMovement(1, 8), 0.1f);
    }
    //End of p1 Movement


    //Player 2 Item Collection
    [UnityTest]
    public void collectYes1_Input()
    {
        Assert.AreEqual(1, new PlayerPositions().CalculateCollection(1,1), 0.1f);
    }
    //Player 1 Item Collection
    [UnityTest]
    public void collectYes2_Input()
    {
        Assert.AreEqual(1, new PlayerPositions().CalculateCollection(1, 2), 0.1f);
    }
    //Player 1 Wins Game (Collects items before other player)
    [UnityTest]
    public void WinYes1_Input()
    {
        Assert.AreEqual(1, new PlayerPositions().CalculateVictory(1), 0.1f);
    }
    //Player 2 Wins Game  (Collects items before other player)
    [UnityTest]
    public void WinYes2_Input()
    {
        Assert.AreEqual(1, new PlayerPositions().CalculateVictory(2), 0.1f);
    }
    //Main Menu "1p" Button Test
    [UnityTest]
    public void button1Yes_Input()
    {
        Assert.AreEqual(1, new PlayerPositions().CalculatePress(1), 0.1f);
    }
    //Main Menu "2p" Button Test
    [UnityTest]
    public void button2Yes_Input()
    {
        Assert.AreEqual(1, new PlayerPositions().CalculatePress(2), 0.1f);
    }
    //Main Menu "0p"/Exit Game test
    [UnityTest]
    public void button3Yes_Input()
    {
        Assert.AreEqual(1, new PlayerPositions().CalculatePress(3), 0.1f);
    }
    //Player 2 failed to collect item
    [UnityTest]
    public void collectNo1_Input()
    {
        Assert.AreEqual(1, new PlayerPositions().CalculateCollection(1,1), 0.1f);
    }
    //Player 1 Failed to collect item
    [UnityTest]
    public void collectNo2_Input()
    {
        Assert.AreEqual(1, new PlayerPositions().CalculateCollection(1,2), 0.1f);
    }
    //Player 1 Did not Switch Directions
    [UnityTest]
    public void turn1No_Input()
    {
        Assert.AreEqual(1, new PlayerPositions().CalculateSwitch(1), 0.1f);
    }
    //Player 2 Did not switch Directions
    [UnityTest]
    public void turn2No_Input()
    {
        Assert.AreEqual(1, new PlayerPositions().CalculateSwitch(2), 0.1f);
    }
    //Player 1 Did switched Directions
    [UnityTest]
    public void turn1Yes_Input()
    {
        Assert.AreEqual(1, new PlayerPositions().CalculateSwitch(1), 0.1f);
    }
    //Player 2 Did switched Directions
    [UnityTest]
    public void turn2Yes_Input()
    {
        Assert.AreEqual(1, new PlayerPositions().CalculateSwitch(2), 0.1f);
    }
    //Player 1 Fell Down
    [UnityTest]
    public void fallYes1_Input()
    {
        Assert.AreEqual(1, new PlayerPositions().CalculateMovement(0,3), 0.1f);
    }
    //Player 2 Fell Down
    [UnityTest]
    public void fallYes2_Input()
    {
        Assert.AreEqual(1, new PlayerPositions().CalculateMovement(0,4), 0.1f);
    }
    //Player 1 Did not fall
    [UnityTest]
    public void fallNo1_Input()
    {
        Assert.AreEqual(1, new PlayerPositions().CalculateMovement(0,3), 0.1f);
    }
    //Player 2 Did not Fall
    [UnityTest]
    public void fallNo2_Input()
    {
        Assert.AreEqual(1, new PlayerPositions().CalculateMovement(0,4), 0.1f);
    }
    //Scenario 1: Player 2 Moves left collects items and wins game (should be false)
    [UnityTest]
    public void WinScen1_Input()
    {
        Assert.AreEqual(0.6, new PlayerPositions().CalculateMovement(1, 5), 0.1f);
        Assert.AreEqual(0.4, new PlayerPositions().CalculateMovement(1, 5), 0.1f);
        Assert.AreEqual(0.2, new PlayerPositions().CalculateMovement(1, 5), 0.1f);
        Assert.AreEqual(0.0, new PlayerPositions().CalculateMovement(1, 5), 0.1f);
        Assert.AreEqual(1, new PlayerPositions().CalculateMovement(0, 4), 0.1f);
        Assert.AreEqual(1, new PlayerPositions().CalculateCollection(1, 2), 0.1f);
        Assert.AreEqual(1, new PlayerPositions().CalculateCollection(1, 2), 0.1f);
        
    }
    //Scenario Two Player 1 Moves right collects items and Wins game (should be true)
    [UnityTest]
    public void WinScen2_Input()
    {
        Assert.AreEqual(0.4, new PlayerPositions().CalculateMovement(1, 2), 0.1f);
        Assert.AreEqual(0.6, new PlayerPositions().CalculateMovement(1, 2), 0.1f);
        Assert.AreEqual(0.8, new PlayerPositions().CalculateMovement(1, 2), 0.1f);
        Assert.AreEqual(1.0, new PlayerPositions().CalculateMovement(1, 2), 0.1f);
        Assert.AreEqual(1, new PlayerPositions().CalculateMovement(0, 3), 0.1f);
        Assert.AreEqual(1, new PlayerPositions().CalculateCollection(1, 1), 0.1f);
        Assert.AreEqual(1, new PlayerPositions().CalculateCollection(1, 1), 0.1f);
    }


}
